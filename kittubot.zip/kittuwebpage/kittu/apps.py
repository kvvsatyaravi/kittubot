from django.apps import AppConfig


class KittuConfig(AppConfig):
    name = 'kittu'
