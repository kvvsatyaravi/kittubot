from django.contrib import admin

# Register your models here.
from kittu.models import funday
admin.site.register(funday)